// Selecting necessary elements
const body = document.querySelector("body"),
  sidebar = body.querySelector(".sidebar"),
  toggle = body.querySelector(".toggle"),
  searchBtn = body.querySelector(".search-box"),
  modeSwitch = body.querySelector(".toggle-switch"),
  modeText = body.querySelector(".mode-text"),
  container = document.querySelector(".container"),  // Kontainer latihan
  scoreDisplay = document.getElementById("userScore");  // Score display element

let userScore = 0;
const maxScore = 100;
const correctAnswerPoints = maxScore / 5; // Assume 5 questions with max score 100
let currentMaterial = ''; // Variable to store current material name

// Sidebar toggle function
toggle.addEventListener("click", () => {
  sidebar.classList.toggle("close");

  // Adjust container padding based on sidebar status
  if (sidebar.classList.contains('close')) {
    container.style.paddingLeft = '70px';  // Sidebar closed
  } else {
    container.style.paddingLeft = '250px';  // Sidebar opened
  }
});

// Dark mode switch function
modeSwitch.addEventListener("click", () => {
  body.classList.toggle("dark");
});

// Function to toggle answer visibility
function toggleAnswer(questionNumber) {
  var button = document.getElementById('toggleButton' + questionNumber);
  var jawabanInput = document.getElementById('jawabanInput' + questionNumber);
  var submitButton = document.getElementById('submitButton' + questionNumber);
  
  // Check if the answer input is empty
  if (!jawabanInput.value || jawabanInput.value.trim() === '') {  
    button.textContent = 'Sembunyikan Jawaban'; 
    jawabanInput.value = getCorrectAnswer(questionNumber);  // Fill input with correct answer for the question
    submitButton.style.display = 'none';  // Hide submit button
  } else {
    button.textContent = 'Tampilkan Jawaban'; 
    jawabanInput.value = '';  // Clear the input field
    submitButton.style.display = 'block';  // Show submit button
  }
}

// Function to handle submit button
function submitJawaban(questionNumber) {
  var jawabanInput = document.getElementById('jawabanInput' + questionNumber).value;
  var jawabanUser = document.getElementById('jawabanUser' + questionNumber);
  var correctAnswer = getCorrectAnswer(questionNumber);

  // Check if the provided answer is correct
  if (jawabanInput == correctAnswer) {
    jawabanUser.textContent = "Jawaban Anda Benar!";
    jawabanUser.style.color = '#39FF14';  // Green for correct answer

    // Increase score if the answer is correct
    userScore += correctAnswerPoints;
    
    // Check if the toggleButton and materiButton exist before modifying
    var toggleButton = document.getElementById('toggleButton' + questionNumber);
    var materiButton = document.getElementById('materiButton' + questionNumber);
    
    if (toggleButton) {
      toggleButton.style.display = 'block';
    }
    if (materiButton) {
      materiButton.style.display = 'block';
    }

  } else {
    jawabanUser.textContent = "Jawaban Anda Salah!";
    jawabanUser.style.color = '#FF6347';  // Red for incorrect answer
  }

  // Update the score display after every submission
  updateScoreDisplay();
}

// Function to update the score display and send it to the server
function updateScoreDisplay() {
  // Update the score dynamically
  scoreDisplay.textContent = `Skor Anda: ${userScore}`;

  // Send the score to the server to save progress
  if (currentMaterial) {
    fetch('/submit_material_progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        score: userScore,  // Send the current score
        material: currentMaterial, // Send the current material
        is_praktikum: false
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.message) {
        console.log("Progress updated on server:", data.message);
      } else {
        console.error("Failed to update progress:", data.error);
      }
    })
    .catch(error => console.error("Error:", error));
  } else {
    console.error("No material selected");
  }
}

// Function to get the correct answer for each question
function getCorrectAnswer(questionNumber) {
  switch (questionNumber) {
    case 1:
      return 5;
    case 2:
      return 1;
    case 3:
      return 'Jakarta';
    case 4:
      return 3;
    case 5:
      return 'Biru';
    default:
      return '';
  }
}

// Function to toggle visibility of the related materials
function toggleMateri(questionNumber) {
  var materiDiv = document.getElementById('materi' + questionNumber);

  // Toggle visibility of material explanation
  if (materiDiv.classList.contains('hidden')) {
    materiDiv.classList.remove('hidden');
  } else {
    materiDiv.classList.add('hidden');
  }
}

// Get material from URL parameter
function getCurrentMaterialFromURL() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('material');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function () {
  // Get material from URL
  const material = getCurrentMaterialFromURL();
  if (material) {
    currentMaterial = material;
    console.log('Current material set to:', material);

    // Update page title or other UI elements to reflect the current material
    const pageTitle = document.querySelector('h1');
    if (pageTitle) {
      pageTitle.textContent = `Latihan - ${material.replace(/_/g, ' ')}`;
    }
  } else {
    console.error('No material specified in URL');
  }
});
